// Unit 9: Statistics
// Data Distributions, Binomial Probability, Normal Distribution, Empirical Rule

// Create Unit 9 namespace
window.Unit9 = {
    
    // Data Distributions
    updateDistribution: function() {
        const canvas = document.getElementById('distributionCanvas');
        if (!canvas) return;
        
        const ctx = canvasContexts['distributionCanvas'];
        drawGrid(ctx, canvas);
        
        // Draw normal distribution curve
        this.drawNormalDistribution(ctx, canvas);
        
        const infoDiv = document.getElementById('distributionResults');
        if (infoDiv) {
            infoDiv.innerHTML = `
                <div><strong>Normal Distribution</strong></div>
                <div>Bell-shaped curve</div>
                <div>Symmetric about the mean</div>
                <div>Mean = Median = Mode</div>
                <div>Empirical Rule (68-95-99.7)</div>
            `;
        }
    },

    drawNormalDistribution: function(ctx, canvas) {
        const scale = 40;
        const startX = -canvas.width / (2 * scale);
        const endX = canvas.width / (2 * scale);
        
        ctx.strokeStyle = '#667eea';
        ctx.lineWidth = 3;
        ctx.beginPath();
        
        let first = true;
        
        for (let x = startX; x <= endX; x += 0.1) {
            // Standard normal distribution: f(x) = (1/√(2π)) * e^(-x²/2)
            const y = (1 / Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * x * x);
            const scaledY = y * 5; // Scale for visibility
            
            const canvasX = x * scale;
            const canvasY = scaledY * scale;
            
            if (first) {
                ctx.moveTo(canvasX, canvasY);
                first = false;
            } else {
                ctx.lineTo(canvasX, canvasY);
            }
        }
        
        ctx.stroke();
        
        // Mark standard deviations
        ctx.fillStyle = '#F44336';
        for (let i = -2; i <= 2; i++) {
            if (i !== 0) {
                const x = i * scale;
                const y = (1 / Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * i * i) * 5 * scale;
                ctx.beginPath();
                ctx.arc(x, y, 4, 0, 2 * Math.PI);
                ctx.fill();
            }
        }
    },

    showEmpiricalRule: function() {
        const infoDiv = document.getElementById('distributionResults');
        if (infoDiv) {
            infoDiv.innerHTML = `
                <div><strong>Empirical Rule (68-95-99.7)</strong></div>
                <div><strong>68%</strong> of data within 1 standard deviation</div>
                <div><strong>95%</strong> of data within 2 standard deviations</div>
                <div><strong>99.7%</strong> of data within 3 standard deviations</div>
                <div>Applies to normal (bell-shaped) distributions</div>
            `;
        }
    },

    calculateZScore: function() {
        const value = parseFloat(document.getElementById('dataValue').value) || 0;
        const mean = parseFloat(document.getElementById('mean').value) || 0;
        const stdDev = parseFloat(document.getElementById('stdDev').value) || 1;
        
        if (stdDev === 0) {
            const infoDiv = document.getElementById('distributionResults');
            if (infoDiv) {
                infoDiv.innerHTML = '<div><strong>Error:</strong> Standard deviation cannot be zero</div>';
            }
            return;
        }
        
        const zScore = (value - mean) / stdDev;
        
        const infoDiv = document.getElementById('distributionResults');
        if (infoDiv) {
            infoDiv.innerHTML = `
                <div><strong>Z-Score Calculation</strong></div>
                <div>Data value (x): ${value}</div>
                <div>Mean (μ): ${mean}</div>
                <div>Standard deviation (σ): ${stdDev}</div>
                <div><strong>z = (x - μ) / σ = (${value} - ${mean}) / ${stdDev} = ${zScore.toFixed(4)}</strong></div>
                <div>Interpretation: ${Math.abs(zScore).toFixed(2)} standard deviations ${zScore >= 0 ? 'above' : 'below'} the mean</div>
            `;
        }
    },

    showBinomialProbability: function() {
        const infoDiv = document.getElementById('distributionResults');
        if (infoDiv) {
            infoDiv.innerHTML = `
                <div><strong>Binomial Probability</strong></div>
                <div><strong>Formula:</strong> P(X = k) = C(n,k) × p^k × (1-p)^(n-k)</div>
                <div><strong>Conditions:</strong></div>
                <div>• Fixed number of trials (n)</div>
                <div>• Two possible outcomes (success/failure)</div>
                <div>• Constant probability (p)</div>
                <div>• Independent trials</div>
                <div><strong>Mean:</strong> μ = np</div>
                <div><strong>Standard Deviation:</strong> σ = √(np(1-p))</div>
            `;
        }
    },

    calculateBinomial: function() {
        const n = parseInt(document.getElementById('trials').value) || 10;
        const k = parseInt(document.getElementById('successes').value) || 5;
        const p = parseFloat(document.getElementById('probability').value) || 0.5;
        
        if (k > n || p < 0 || p > 1) {
            const infoDiv = document.getElementById('distributionResults');
            if (infoDiv) {
                infoDiv.innerHTML = '<div><strong>Error:</strong> Invalid parameters</div>';
            }
            return;
        }
        
        // Calculate combination C(n,k)
        function combination(n, k) {
            if (k > n) return 0;
            if (k === 0 || k === n) return 1;
            
            let result = 1;
            for (let i = 0; i < k; i++) {
                result *= (n - i) / (i + 1);
            }
            return result;
        }
        
        const comb = combination(n, k);
        const probability = comb * Math.pow(p, k) * Math.pow(1 - p, n - k);
        const mean = n * p;
        const stdDev = Math.sqrt(n * p * (1 - p));
        
        const infoDiv = document.getElementById('distributionResults');
        if (infoDiv) {
            infoDiv.innerHTML = `
                <div><strong>Binomial Probability Calculation</strong></div>
                <div>Trials (n): ${n}</div>
                <div>Successes (k): ${k}</div>
                <div>Probability (p): ${p}</div>
                <div>C(${n},${k}): ${comb}</div>
                <div><strong>P(X = ${k}) = ${probability.toFixed(6)}</strong></div>
                <div>Mean: ${mean.toFixed(2)}</div>
                <div>Standard Deviation: ${stdDev.toFixed(4)}</div>
            `;
        }
    }
};

console.log('Unit 9 (Statistics) module loaded successfully');