// Unit 2: Polynomials
// Polynomial Graphs, Operations, Factoring, Division, and Equations

// Create Unit 2 namespace
window.Unit2 = {
    
    // Polynomial Graphs
    updatePolynomial: function() {
        const canvas = document.getElementById('polynomialCanvas');
        if (!canvas) return;
        
        const ctx = canvasContexts['polynomialCanvas'];
        drawGrid(ctx, canvas);
        
        const degree = document.getElementById('polynomialDegree').value;
        const leadingCoeff = parseFloat(document.getElementById('leadingCoeff').value) || 1;
        const constantTerm = parseFloat(document.getElementById('constantTerm').value) || 0;
        
        // Update display values
        document.getElementById('leadingCoeffValue').textContent = leadingCoeff;
        document.getElementById('constantTermValue').textContent = constantTerm;
        
        switch(degree) {
            case 'linear':
                drawLinearPolynomial(ctx, canvas, leadingCoeff, constantTerm);
                this.updatePolynomialInfo('Linear', `f(x) = ${leadingCoeff}x + ${constantTerm}`, 'Degree: 1', 'Continuous, straight line');
                break;
            case 'quadratic':
                drawQuadraticPolynomial(ctx, canvas, leadingCoeff, 0, constantTerm);
                this.updatePolynomialInfo('Quadratic', `f(x) = ${leadingCoeff}x² + ${constantTerm}`, 'Degree: 2', 'Parabola with 1 turning point');
                break;
            case 'cubic':
                this.drawCubicPolynomial(ctx, canvas, leadingCoeff, constantTerm);
                this.updatePolynomialInfo('Cubic', `f(x) = ${leadingCoeff}x³ + ${constantTerm}`, 'Degree: 3', 'Up to 2 turning points');
                break;
            case 'quartic':
                this.drawQuarticPolynomial(ctx, canvas, leadingCoeff, constantTerm);
                this.updatePolynomialInfo('Quartic', `f(x) = ${leadingCoeff}x⁴ + ${constantTerm}`, 'Degree: 4', 'Up to 3 turning points');
                break;
        }
    },

    drawCubicPolynomial: function(ctx, canvas, a) {
        const scale = 40;
        const startX = -canvas.width / (2 * scale);
        const endX = canvas.width / (2 * scale);
        
        ctx.strokeStyle = '#667eea';
        ctx.lineWidth = 3;
        ctx.beginPath();
        
        let first = true;
        
        for (let x = startX; x <= endX; x += 0.1) {
            const y = a * x * x * x;
            
            if (Math.abs(y) < 15) {
                const canvasX = x * scale;
                const canvasY = y * scale;
                
                if (first) {
                    ctx.moveTo(canvasX, canvasY);
                    first = false;
                } else {
                    ctx.lineTo(canvasX, canvasY);
                }
            }
        }
        
        ctx.stroke();
    },

    drawQuarticPolynomial: function(ctx, canvas, a) {
        const scale = 40;
        const startX = -canvas.width / (2 * scale);
        const endX = canvas.width / (2 * scale);
        
        ctx.strokeStyle = '#667eea';
        ctx.lineWidth = 3;
        ctx.beginPath();
        
        let first = true;
        
        for (let x = startX; x <= endX; x += 0.1) {
            const y = a * x * x * x * x;
            
            if (Math.abs(y) < 15) {
                const canvasX = x * scale;
                const canvasY = y * scale;
                
                if (first) {
                    ctx.moveTo(canvasX, canvasY);
                    first = false;
                } else {
                    ctx.lineTo(canvasX, canvasY);
                }
            }
        }
        
        ctx.stroke();
    },

    updatePolynomialInfo: function(degree, leadingCoeff) {
        const infoDiv = document.getElementById('polynomialResults');
        if (infoDiv) {
            let endBehavior = '';
            if (degree === '2') {
                endBehavior = leadingCoeff > 0 ? 'Both ends up' : 'Both ends down';
            } else if (degree === '3') {
                endBehavior = leadingCoeff > 0 ? 'Left down, Right up' : 'Left up, Right down';
            } else if (degree === '4') {
                endBehavior = leadingCoeff > 0 ? 'Both ends up' : 'Both ends down';
            }
            
            infoDiv.innerHTML = `
                <div><strong>Degree ${degree} polynomial</strong></div>
                <div>Leading coefficient: ${leadingCoeff}</div>
                <div>End behavior: ${endBehavior}</div>
            `;
        }
    },

    analyzePolynomial: function() {
        const degree = document.getElementById('polynomialDegree').value;
        const leadingCoeff = parseFloat(document.getElementById('leadingCoeff').value) || 1;
        
        let analysis = '';
        
        switch(degree) {
            case 'linear':
                analysis = `<strong>Linear Function End Behavior:</strong><br>`;
                analysis += leadingCoeff > 0 ? 
                    'As x → -∞, f(x) → -∞<br>As x → +∞, f(x) → +∞' :
                    'As x → -∞, f(x) → +∞<br>As x → +∞, f(x) → -∞';
                break;
            case 'quadratic':
                analysis = `<strong>Quadratic Function End Behavior:</strong><br>`;
                analysis += leadingCoeff > 0 ? 
                    'As x → ±∞, f(x) → +∞<br><strong>Upward-opening parabola</strong>' :
                    'As x → ±∞, f(x) → -∞<br><strong>Downward-opening parabola</strong>';
                break;
            case 'cubic':
                analysis = `<strong>Cubic Function End Behavior:</strong><br>`;
                analysis += leadingCoeff > 0 ? 
                    'As x → -∞, f(x) → -∞<br>As x → +∞, f(x) → +∞' :
                    'As x → -∞, f(x) → +∞<br>As x → +∞, f(x) → -∞';
                break;
            case 'quartic':
                analysis = `<strong>Quartic Function End Behavior:</strong><br>`;
                analysis += leadingCoeff > 0 ? 
                    'As x → ±∞, f(x) → +∞<br><strong>Both ends go up</strong>' :
                    'As x → ±∞, f(x) → -∞<br><strong>Both ends go down</strong>';
                break;
        }
        
        const infoDiv = document.getElementById('polynomialResults');
        if (infoDiv) {
            infoDiv.innerHTML = analysis;
        }
    },

    findTurningPoints: function() {
        const degree = document.getElementById('polynomialDegree').value;
        
        let turningPoints = '';
        
        switch(degree) {
            case 'linear':
                turningPoints = '<strong>Linear Functions:</strong><br>No turning points.<br>They are monotonic (always increasing or decreasing).';
                break;
            case 'quadratic':
                turningPoints = '<strong>Quadratic Functions:</strong><br>Exactly <strong>1 turning point</strong><br>The vertex of the parabola.';
                break;
            case 'cubic':
                turningPoints = '<strong>Cubic Functions:</strong><br>At most <strong>2 turning points</strong><br>One local maximum and one local minimum (if they exist).';
                break;
            case 'quartic':
                turningPoints = '<strong>Quartic Functions:</strong><br>At most <strong>3 turning points</strong><br>Alternating between local maxima and minima.';
                break;
        }
        
        const infoDiv = document.getElementById('polynomialResults');
        if (infoDiv) {
            infoDiv.innerHTML = turningPoints;
        }
    },

    // Polynomial Operations
    updateOperations: function() {
        const infoDiv = document.getElementById('operationsResults');
        if (infoDiv) {
            infoDiv.innerHTML = '<div>Enter polynomials and select an operation to see results.</div>';
        }
    },

    performOperation: function() {
        const poly1 = document.getElementById('polynomial1').value.trim();
        const poly2 = document.getElementById('polynomial2').value.trim();
        const operation = document.getElementById('operation').value;
        
        if (!poly1 || !poly2) {
            const infoDiv = document.getElementById('operationsResults');
            if (infoDiv) {
                infoDiv.innerHTML = '<div><strong>Error:</strong> Please enter both polynomials</div>';
            }
            return;
        }
        
        let result = '';
        
        switch(operation) {
            case 'add':
                result = `<strong>Addition:</strong><br>(${poly1}) + (${poly2})<br><br>`;
                result += 'Combine like terms to get the sum.';
                break;
            case 'subtract':
                result = `<strong>Subtraction:</strong><br>(${poly1}) - (${poly2})<br><br>`;
                result += 'Distribute the negative and combine like terms.';
                break;
            case 'multiply':
                result = `<strong>Multiplication:</strong><br>(${poly1}) × (${poly2})<br><br>`;
                result += 'Use FOIL or distribution to multiply all terms.';
                break;
        }
        
        const infoDiv = document.getElementById('operationsResults');
        if (infoDiv) {
            infoDiv.innerHTML = result;
        }
    },

    // Factoring
    updateFactoring: function() {
        const infoDiv = document.getElementById('factoringResults');
        if (infoDiv) {
            infoDiv.innerHTML = '<div>Enter a polynomial to factor it.</div>';
        }
    },

    factorPolynomial: function() {
        const polynomial = document.getElementById('factorInput').value.trim();
        
        if (!polynomial) {
            const infoDiv = document.getElementById('factoringResults');
            if (infoDiv) {
                infoDiv.innerHTML = '<div><strong>Error:</strong> Please enter a polynomial</div>';
            }
            return;
        }
        
        let result = `<strong>Factoring: ${polynomial}</strong><br><br>`;
        
        // Simple factoring examples
        if (polynomial.includes('x²')) {
            result += '<strong>Steps:</strong><br>';
            result += '1. Look for common factors<br>';
            result += '2. Check if it\'s a perfect square trinomial<br>';
            result += '3. Try factoring by grouping<br>';
            result += '4. Use quadratic formula if needed';
        } else {
            result += 'Factor out common terms and look for patterns.';
        }
        
        const infoDiv = document.getElementById('factoringResults');
        if (infoDiv) {
            infoDiv.innerHTML = result;
        }
    },

    showFactoringMethods: function() {
        const method = document.getElementById('factoringMethod').value;
        let result = '';
        
        switch(method) {
            case 'gcf':
                result = '<strong>Greatest Common Factor (GCF):</strong><br>Factor out the largest common factor from all terms.<br>Example: 6x³ + 9x² = 3x²(2x + 3)';
                break;
            case 'grouping':
                result = '<strong>Factoring by Grouping:</strong><br>Group terms and factor each group.<br>Example: ax + bx + ay + by = x(a + b) + y(a + b) = (x + y)(a + b)';
                break;
            case 'trinomial':
                result = '<strong>Factoring Trinomials:</strong><br>Find two numbers that multiply to ac and add to b.<br>Example: x² + 5x + 6 = (x + 2)(x + 3)';
                break;
            case 'difference':
                result = '<strong>Difference of Squares:</strong><br>a² - b² = (a + b)(a - b)<br>Example: x² - 9 = (x + 3)(x - 3)';
                break;
        }
        
        const infoDiv = document.getElementById('factoringResults');
        if (infoDiv) {
            infoDiv.innerHTML = result;
        }
    },

    // Polynomial Division
    updateDivision: function() {
        const infoDiv = document.getElementById('divisionResults');
        if (infoDiv) {
            infoDiv.innerHTML = '<div>Enter dividend and divisor to perform polynomial division.</div>';
        }
    },

    performDivision: function() {
        const dividend = document.getElementById('dividend').value.trim();
        const divisor = document.getElementById('divisor').value.trim();
        
        if (!dividend || !divisor) {
            const infoDiv = document.getElementById('divisionResults');
            if (infoDiv) {
                infoDiv.innerHTML = '<div><strong>Error:</strong> Please enter both dividend and divisor</div>';
            }
            return;
        }
        
        let result = `<strong>Dividing:</strong> (${dividend}) ÷ (${divisor})<br><br>`;
        result += '<strong>Steps for Polynomial Long Division:</strong><br>';
        result += '1. Divide the leading term of dividend by leading term of divisor<br>';
        result += '2. Multiply the entire divisor by this quotient<br>';
        result += '3. Subtract from the dividend<br>';
        result += '4. Repeat with the new dividend<br>';
        result += '5. Continue until degree of remainder < degree of divisor';
        
        const infoDiv = document.getElementById('divisionResults');
        if (infoDiv) {
            infoDiv.innerHTML = result;
        }
    },

    showSyntheticDivision: function() {
        const dividend = document.getElementById('dividend').value.trim();
        
        let result = '<strong>Synthetic Division:</strong><br>';
        result += 'Used when dividing by (x - c) where c is a constant.<br><br>';
        result += '<strong>Steps:</strong><br>';
        result += '1. Write coefficients of dividend<br>';
        result += '2. Use c as the synthetic divisor<br>';
        result += '3. Bring down first coefficient<br>';
        result += '4. Multiply by c, add to next coefficient<br>';
        result += '5. Repeat until complete';
        
        if (dividend) {
            result += `<br><br><strong>Example with:</strong> ${dividend}`;
        }
        
        const infoDiv = document.getElementById('divisionResults');
        if (infoDiv) {
            infoDiv.innerHTML = result;
        }
    },

    // Polynomial Equations
    updateEquations: function() {
        const infoDiv = document.getElementById('equationsResults');
        if (infoDiv) {
            infoDiv.innerHTML = '<div>Enter a polynomial equation to solve it.</div>';
        }
    },

    solvePolynomialEquation: function() {
        const equation = document.getElementById('equationInput').value.trim();
        
        if (!equation) {
            const infoDiv = document.getElementById('equationsResults');
            if (infoDiv) {
                infoDiv.innerHTML = '<div><strong>Error:</strong> Please enter a polynomial equation</div>';
            }
            return;
        }
        
        let result = `<strong>Solving:</strong> ${equation}<br><br>`;
        result += '<strong>General Steps:</strong><br>';
        result += '1. Set the polynomial equal to zero<br>';
        result += '2. Factor the polynomial if possible<br>';
        result += '3. Use the Zero Product Property<br>';
        result += '4. Solve each factor for x<br><br>';
        result += 'For higher degree polynomials, use the Rational Root Theorem to find possible rational roots.';
        
        const infoDiv = document.getElementById('equationsResults');
        if (infoDiv) {
            infoDiv.innerHTML = result;
        }
    },

    findRationalRoots: function() {
        const equation = document.getElementById('equationInput').value.trim();
        
        let result = '<strong>Rational Root Theorem:</strong><br>';
        result += 'If p/q is a rational root of a polynomial with integer coefficients,<br>';
        result += 'then p divides the constant term and q divides the leading coefficient.<br><br>';
        result += '<strong>Steps:</strong><br>';
        result += '1. List factors of constant term (p)<br>';
        result += '2. List factors of leading coefficient (q)<br>';
        result += '3. Form all possible p/q ratios<br>';
        result += '4. Test each ratio using synthetic division';
        
        if (equation) {
            result += `<br><br><strong>For equation:</strong> ${equation}`;
        }
        
        const infoDiv = document.getElementById('equationsResults');
        if (infoDiv) {
            infoDiv.innerHTML = result;
        }
    }
};

console.log('Unit 2 (Polynomials) module loaded successfully');