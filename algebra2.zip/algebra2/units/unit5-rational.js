// Unit 5: Rational Functions
// Rational Functions, Asymptotes, and Operations

// Create Unit 5 namespace
window.Unit5 = {
    
    // Rational Functions
    updateRationalFunc: function() {
        const canvas = document.getElementById('rationalFuncCanvas');
        if (!canvas) return;
        
        const ctx = canvasContexts['rationalFuncCanvas'];
        drawGrid(ctx, canvas);
        
        // Draw basic rational function
        drawRationalFunction(ctx, canvas, 2, 0);
        
        const infoDiv = document.getElementById('rationalFuncResults');
        if (infoDiv) {
            infoDiv.innerHTML = `
                <div><strong>Rational Function: f(x) = 1/(x-2)</strong></div>
                <div>Domain: (-∞, 2) ∪ (2, ∞)</div>
                <div>Range: (-∞, 0) ∪ (0, ∞)</div>
                <div>Vertical Asymptote: x = 2</div>
                <div>Horizontal Asymptote: y = 0</div>
            `;
        }
    },

    analyzeAsymptotes: function() {
        const infoDiv = document.getElementById('rationalFuncResults');
        if (infoDiv) {
            infoDiv.innerHTML = `
                <div><strong>Asymptote Analysis</strong></div>
                <div><strong>Vertical Asymptotes:</strong> Set denominator = 0</div>
                <div><strong>Horizontal Asymptotes:</strong> Compare degrees of numerator and denominator</div>
                <div>• If deg(num) < deg(den): y = 0</div>
                <div>• If deg(num) = deg(den): y = ratio of leading coefficients</div>
                <div>• If deg(num) > deg(den): no horizontal asymptote</div>
            `;
        }
    },

    findHoles: function() {
        const infoDiv = document.getElementById('rationalFuncResults');
        if (infoDiv) {
            infoDiv.innerHTML = `
                <div><strong>Finding Holes</strong></div>
                <div>Holes occur when a factor cancels from both numerator and denominator</div>
                <div>1. Factor numerator and denominator completely</div>
                <div>2. Identify common factors</div>
                <div>3. Cancel common factors to find holes</div>
                <div>4. Remaining factors in denominator give vertical asymptotes</div>
            `;
        }
    }
};

console.log('Unit 5 (Rational Functions) module loaded successfully');