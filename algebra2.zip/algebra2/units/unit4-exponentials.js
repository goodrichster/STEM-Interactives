// Unit 4: Exponentials & Logarithms
// Exponential Functions, Logarithmic Functions, Exponential Equations, Logarithmic Equations, Applications

// Create Unit 4 namespace
window.Unit4 = {
    
    // Exponential Functions
    updateExponential: function() {
        const canvas = document.getElementById('exponentialCanvas');
        if (!canvas) return;
        
        const ctx = canvasContexts['exponentialCanvas'];
        drawGrid(ctx, canvas);
        
        // Draw basic exponential function
        drawExponentialFunction(ctx, canvas, 1, 2, 0);
        
        const infoDiv = document.getElementById('exponentialResults');
        if (infoDiv) {
            infoDiv.innerHTML = `
                <div><strong>Exponential Function: f(x) = 2^x</strong></div>
                <div>Domain: (-∞, ∞)</div>
                <div>Range: (0, ∞)</div>
                <div>Horizontal Asymptote: y = 0</div>
            `;
        }
    },

    // Logarithmic Functions
    updateLogarithmic: function() {
        const canvas = document.getElementById('logarithmicCanvas');
        if (!canvas) return;
        
        const ctx = canvasContexts['logarithmicCanvas'];
        drawGrid(ctx, canvas);
        
        // Draw basic logarithmic function
        drawLogarithmicFunction(ctx, canvas, 1, 0, 0);
        
        const infoDiv = document.getElementById('logarithmicResults');
        if (infoDiv) {
            infoDiv.innerHTML = `
                <div><strong>Logarithmic Function: f(x) = log(x)</strong></div>
                <div>Domain: (0, ∞)</div>
                <div>Range: (-∞, ∞)</div>
                <div>Vertical Asymptote: x = 0</div>
            `;
        }
    },

    // Exponential Equations
    updateExpEq: function() {
        const infoDiv = document.getElementById('expEqResults');
        if (infoDiv) {
            infoDiv.innerHTML = `
                <div><strong>Solving Exponential Equations</strong></div>
                <div>1. If bases are the same: a^x = a^y → x = y</div>
                <div>2. If bases are different: take log of both sides</div>
                <div>3. Use properties of logarithms to solve</div>
            `;
        }
    },

    // Logarithmic Equations
    updateLogEq: function() {
        const infoDiv = document.getElementById('logEqResults');
        if (infoDiv) {
            infoDiv.innerHTML = `
                <div><strong>Solving Logarithmic Equations</strong></div>
                <div>1. Use properties of logarithms to simplify</div>
                <div>2. Convert to exponential form if needed</div>
                <div>3. Check solutions in original equation</div>
            `;
        }
    },

    // Applications
    updateApplications: function() {
        const infoDiv = document.getElementById('applicationsResults');
        if (infoDiv) {
            infoDiv.innerHTML = `
                <div><strong>Exponential Applications</strong></div>
                <div>• Compound Interest: A = P(1 + r/n)^(nt)</div>
                <div>• Population Growth: P(t) = P₀e^(rt)</div>
                <div>• Radioactive Decay: N(t) = N₀e^(-λt)</div>
                <div>• pH Scale: pH = -log[H⁺]</div>
            `;
        }
    }
};

console.log('Unit 4 (Exponentials & Logarithms) module loaded successfully');