// Unit 6: Sequences & Series
// Arithmetic Sequences, Geometric Sequences, and Series

// Create Unit 6 namespace
window.Unit6 = {
    
    // Arithmetic Sequences
    updateArithmetic: function() {
        const canvas = document.getElementById('arithmeticCanvas');
        if (!canvas) return;
        
        const ctx = canvasContexts['arithmeticCanvas'];
        drawGrid(ctx, canvas);
        
        // Draw arithmetic sequence points
        this.drawArithmeticSequence(ctx, canvas);
        
        const infoDiv = document.getElementById('arithmeticResults');
        if (infoDiv) {
            infoDiv.innerHTML = `
                <div><strong>Arithmetic Sequence</strong></div>
                <div>General Term: aₙ = a₁ + (n-1)d</div>
                <div>Common Difference: d = aₙ₊₁ - aₙ</div>
                <div>Sum Formula: Sₙ = n(a₁ + aₙ)/2</div>
            `;
        }
    },

    drawArithmeticSequence: function(ctx, canvas) {
        const scale = 40;
        const a1 = 2; // First term
        const d = 3;  // Common difference
        
        ctx.fillStyle = '#667eea';
        
        for (let n = 1; n <= 8; n++) {
            const an = a1 + (n - 1) * d;
            const x = n;
            const y = an;
            
            if (Math.abs(y) < 15) {
                ctx.beginPath();
                ctx.arc(x * scale, y * scale, 6, 0, 2 * Math.PI);
                ctx.fill();
            }
        }
    },

    calculateTerm: function() {
        const a1 = parseFloat(document.getElementById('firstTerm').value) || 2;
        const d = parseFloat(document.getElementById('commonDiff').value) || 3;
        const n = parseInt(document.getElementById('termNumber').value) || 10;
        
        const an = a1 + (n - 1) * d;
        
        const infoDiv = document.getElementById('arithmeticResults');
        if (infoDiv) {
            infoDiv.innerHTML = `
                <div><strong>Arithmetic Sequence Calculation</strong></div>
                <div>First term (a₁): ${a1}</div>
                <div>Common difference (d): ${d}</div>
                <div>Term number (n): ${n}</div>
                <div><strong>aₙ = a₁ + (n-1)d = ${a1} + (${n}-1)(${d}) = ${an}</strong></div>
            `;
        }
    },

    calculateSum: function() {
        const a1 = parseFloat(document.getElementById('firstTerm').value) || 2;
        const d = parseFloat(document.getElementById('commonDiff').value) || 3;
        const n = parseInt(document.getElementById('termNumber').value) || 10;
        
        const an = a1 + (n - 1) * d;
        const sum = n * (a1 + an) / 2;
        
        const infoDiv = document.getElementById('arithmeticResults');
        if (infoDiv) {
            infoDiv.innerHTML = `
                <div><strong>Arithmetic Series Sum</strong></div>
                <div>Number of terms: ${n}</div>
                <div>First term: ${a1}</div>
                <div>Last term: ${an}</div>
                <div><strong>Sₙ = n(a₁ + aₙ)/2 = ${n}(${a1} + ${an})/2 = ${sum}</strong></div>
            `;
        }
    }
};

console.log('Unit 6 (Sequences) module loaded successfully');